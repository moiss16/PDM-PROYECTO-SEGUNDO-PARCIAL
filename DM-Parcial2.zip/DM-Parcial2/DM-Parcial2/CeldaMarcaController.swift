//
//  CeldaMarcaController.swift
//  DM-Parcial2
//
//  Created by David Encinas on 25/10/21.
//

import Foundation
import UIKit

class CeldaMarcaController : UITableViewCell{
    
    @IBOutlet weak var imgMarca: UIImageView!
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblPrecio: UILabel!
}
