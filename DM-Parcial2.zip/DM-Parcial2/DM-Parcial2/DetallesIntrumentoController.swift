//
//  DetallesIntrumentoController.swift
//  DM-Parcial2
//
//  Created by David Encinas on 25/10/21.
//

import Foundation
import UIKit

class DetallesIntrumentosController : UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return marcas.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 195
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaMarca") as! CeldaMarcaController
        celda.lblNombre.text = marcas[indexPath.row].nombre
        celda.lblPrecio.text = marcas[indexPath.row].precio
        celda.imgMarca.image = UIImage(named: marcas[indexPath.row].imgMarca!)
        
        return celda
    }
    
    var marcas : [Marca] = []
    var instrumentos : Instrumento = Instrumento(nombre: "", stock: "", imgInstrumento: "", marcas: [])
    
    override func viewDidLoad(){
        self.title = instrumentos.nombre
    }
    
    @IBOutlet weak var tvMarca: UITableView!
    
}
