//
//  Marca.swift
//  DM-Parcial2
//
//  Created by David Encinas on 25/10/21.
//

import Foundation

class Marca{
    var nombre: String?
    var precio: String?
    var imgMarca: String?
    
    init(nombre: String, precio: String, imgMarca: String){
        self.nombre = nombre
        self.precio = precio
        self.imgMarca = imgMarca
    }
}
