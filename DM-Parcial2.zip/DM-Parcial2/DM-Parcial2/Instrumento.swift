//
//  File.swift
//  DM-Parcial2
//
//  Created by David Encinas on 25/10/21.
//

import Foundation

class Instrumento{
    
    var nombre = ""
    var stock = ""
    var imgInstrumento = ""
    
    var marcas : [Marca] = []
    
    init(nombre: String, stock: String, imgInstrumento : String, marcas: [Marca]){
        self.nombre = nombre
        self.stock = stock
        self.imgInstrumento = imgInstrumento
        self.marcas = marcas
        
    }
    
}
